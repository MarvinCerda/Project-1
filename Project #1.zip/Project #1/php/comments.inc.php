<?php

function setcomments() {
	if (isset($_POST['commentSubmit'])) {
		$uid = $_POST['uid'];
		$date = $_POST['date'];
		$message = $_POST['message'];
		
		$sql = 'INSERT INTO comments (uid,date,message) VALUES('$uid','$date','$message')';
		$result =$conn->query($sql);
	}
}

function getComments($conn) {
	$sql = 'SELECT = FROM comments';
	$result =$conn->query($sql);
	while ($row =$result->fetch.assoc()) {
	echo $row['message'];
	}
}