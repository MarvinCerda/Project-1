<?php
$name="Marvin";
?>
<html>
	<head>
		<style type="text/css">
			
		</style>
		<script type="text/javascript">
			
		</script>
	</head>
	<body>
		<?php
		echo $name;
		?>
	</body>
</html>