<?php

$connect = mysqli_connect('localhost','root',' ','commentsection');

if ($connect) {
	die('Connection failed:' .mysqli_connect_error());
}