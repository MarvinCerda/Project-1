<html>
	<head>
		<style>
			#body {
				color:#99FFFF;
				background-color:#000000;
			}
		</style>
	</head>
	<body>
	<div id="body">
		<?php
		
		?>
	</div>
	</body>
</html>